import logo from './logo.svg';
import './App.css';
import WordCounter from './mainapp.js';


function App() {
 
  return (
    <div>
 <WordCounter/>
    

    </div>
  );
}





export default App;
